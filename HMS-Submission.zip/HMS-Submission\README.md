# 🏥 Hospital Management System (HMS)

<p align="center">
  <strong>A Full-Stack, Role-Based Healthcare Operations & Clinical Scheduling Platform</strong>
</p>

<p align="center">
  Streamlining clinical consultations, concurrent slot booking, doctor availability, AI-assisted pre/post-visit documentation, pharmacy dispensing, hospital billing, and asynchronous notifications within a single secure, role-aware system.
</p>

<p align="center">

[![Live Demo](https://img.shields.io/badge/Live_Demo-Vercel_Deployment-000000?style=for-the-badge&logo=vercel)](https://hospital-management-system-v2-ashy.vercel.app/)

</p>

<p align="center">

![Next.js](https://img.shields.io/badge/Next.js-15.3.2-black?logo=next.js)
![React](https://img.shields.io/badge/React-19-61DAFB?logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-v4-06B6D4?logo=tailwindcss)
![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-3ECF8E?logo=supabase)
![Google Gemini](https://img.shields.io/badge/AI-Google_Gemini-4285F4?logo=google)
![Resend](https://img.shields.io/badge/Email-Resend_API-black)
![Vitest](https://img.shields.io/badge/Testing-Vitest-6E9F18?logo=vitest)

</p>

---

## 🌐 Live Application Demo

🔗 **Production URL:** [https://hospital-management-system-v2-ashy.vercel.app/](https://hospital-management-system-v2-ashy.vercel.app/)

---

## 📚 Deep-Dive Technical Documentation

Comprehensive architectural and engineering references are available in the [`docs/`](./docs) directory:

- 🔌 **[API Reference Documentation](./docs/API.md):** Detailed REST endpoint specifications, Zod schemas, HTTP status codes, and request/response payloads across 62 API routes.
- 🗄️ **[Database Architecture Reference](./docs/DATABASE.md):** Complete PostgreSQL relational schema, 30 tables, enums, indexes, constraints, and atomic PL/pgSQL stored procedures.
- 📆 **[Google Calendar Integration & Setup Guide](./docs/GOOGLE_CALENDAR_SETUP.md):** Step-by-step OAuth 2.0 configuration, AES-256-GCM token encryption, and bi-directional event synchronization.
- 🤖 **[AI / LLM Prompts & Intelligence Reference](./docs/LLM_PROMPTS.md):** Detailed breakdown of Google Gemini (`gemini-3.6-flash`) structured JSON prompts, pre-visit urgency rating, post-visit education, and fallback handling.
- 📐 **[System Design & Architecture Document](./docs/SYSTEM_DESIGN.md):** Concise architectural design, concurrency models, request lifecycles, and key engineering trade-offs.

---

## 📌 1. Project Overview & Problem Solved

Traditional healthcare facilities often struggle with fragmented software where appointment booking, doctor schedules, patient intake, pharmacy dispensing, and billing operate in isolated silos. This causes race-condition double bookings, high no-show rates, administrative overhead, and clinical documentation gaps.

The **Hospital Management System (HMS)** solves these challenges by providing a unified, real-time, role-aware platform that connects:
- **Patients** to verified specialists with real-time atomic slot reservation.
- **Doctors** with automated schedule conflict detection, structured consultation tools, and AI-assisted documentation.
- **Nurses** with inpatient room assignments and patient care monitoring.
- **Pharmacists** with real-time inventory tracking, low-stock alerts, and prescription dispensing.
- **Administrators** with hospital-wide operational analytics, staff provisioning, room allocation, and unified billing.

---

## ✨ 2. Key Features

- **🛡️ Multi-Tenant Role-Based Access Control (RBAC):** Distinct dashboards, route guards, and permission scopes for `Admin`, `Doctor`, `Nurse`, `Patient`, and `Pharmacist`.
- **⏱️ Concurrency-Safe Slot Reservation:** Atomic 5-minute temporary slot holding powered by PostgreSQL advisory locks and transaction-level row locks (`FOR UPDATE`) to eliminate race conditions and double-booking.
- **📅 Dynamic Availability & Doctor Leave Management:** Automated doctor slot generation based on shift windows, break times, and slot duration, coupled with automated conflict detection and rescheduling triggers when leave is approved.
- **🤖 Dual-Stage AI Clinical Intelligence:** Pre-visit symptom intake analysis (chief complaint, urgency rating, clinical summary, and suggested patient questions) and post-visit clinical summary generation powered by Google Gemini with graceful fallback handling.
- **📬 Multi-Channel Notification Engine:** Asynchronous outbox pattern delivering booking confirmations, cancellations, reschedules, and doctor leave alerts via Resend API / SMTP with automated exponential-backoff retries.
- **📆 Google Calendar Bi-Directional Synchronization:** OAuth 2.0 calendar integration featuring client-side AES-256-GCM token encryption (`crypto/vault`) and automated event creation, updating, and cancellation.
- **💊 Pharmacy & Real-Time Stock Management:** Categorized inventory management (`In Stock`, `Low Stock`, `Out of Stock`) with automated transaction logging upon dispensing or restocking.
- **💳 Unified Billing & Invoicing:** Dynamic invoice generation with multi-item categorization (`Medicine`, `Room`, `Consultation`, `Lab`), payment status tracking, and automated calculation.
- **📊 Real-Time Hospital Analytics:** Departmental revenue distribution, patient demographics (gender, blood type), visit frequency trends, and pharmaceutical consumption analytics rendered via Recharts.

---

## 👥 3. Five Role-Based Workspaces

### 🧑‍🤝‍🧑 Patient Workspace (`/patient`)
- **Specialty & Doctor Discovery:** Search and filter active doctors by department and specialization.
- **Interactive Booking:** Live calendar slot picker with real-time 5-minute countdown timers for held slots.
- **AI Pre-Visit Intake:** Guided symptom questionnaire recording severity, duration, worsening factors, and consent.
- **Personal Records & Invoices:** Real-time visibility into past and upcoming appointments, prescriptions, and billing statements.

### 👨‍⚕️ Doctor Workspace (`/doctor`)
- **Clinical Schedule:** Daily and weekly view of confirmed and completed appointments.
- **Consultation & Notes:** Creation of structured post-visit clinical notes, diagnoses, and medication prescriptions.
- **Availability Management:** Configuration of recurring weekly schedules (working days, start/end hours, break times, and slot duration).
- **Leave Application:** Requesting leave with automatic conflict inspection for existing patient bookings.

### 👩‍⚕️ Nurse Workspace (`/nurse`)
- **Inpatient Care Management:** Overview of active admissions, assigned rooms, and patient vitals.
- **Patient Monitoring:** Rapid lookup of patient emergency contacts and blood groups.

### 💊 Pharmacy Workspace (`/pharmacy`)
- **Inventory Control:** Live stock monitoring with visual classification (`In Stock`, `Low Stock < 20`, `Out of Stock = 0`).
- **Dispensing Workflows:** One-click medicine dispensing linked directly to inventory deductions.
- **Stock Replenishment:** Restocking medicines with automated unit cost and stock level updates.

### 🛡️ Administrator Workspace (`/admin`)
- **Staff Provisioning:** Creation, editing, and activation of Doctor, Nurse, Pharmacist, and Admin staff accounts.
- **Room & Nurse Allocation:** Managing hospital rooms and assigning duty nurses to admitted patients.
- **Billing Management:** Invoice generation, line-item pricing (`Medicine`, `Room`, `Consultation`), and payment tracking.
- **Executive Analytics:** Departmental breakdown of revenue, visits, patient demographics, and medicine utilization.

---

## 🛠️ 4. Technology Stack

### Frontend & UI
- **Framework:** Next.js 15.3.2 (React 19, App Router)
- **Styling:** Tailwind CSS v4 with semantic CSS variables
- **Component Primitives:** Radix UI (Dialog, Select, Tabs, Dropdown, Accordion, Tooltip)
- **Icons:** Lucide React
- **Data Visualization:** Recharts
- **Toast Notifications:** Sonner
- **Theming:** `next-themes` (Full Light/Dark mode support)

### Backend & API
- **Runtime:** Node.js 18+ (Next.js Server Runtime & Server Actions)
- **Validation:** Zod v3 schemas for strict request payload validation
- **Security & Crypto:** Web Crypto API / Node `crypto` for AES-256-GCM token encryption

### Database & Auth
- **Platform:** Supabase (PostgreSQL 15+)
- **Authentication:** Supabase Auth (JWT session handling and cookie management via `@supabase/ssr`)
- **Authorization:** PostgreSQL Row Level Security (RLS) policies and stored PL/pgSQL procedures

### External Integrations
- **AI / LLM:** Google Gemini API (`@google/genai` model `gemini-3.6-flash`)
- **Email Delivery:** Resend API / SMTP provider fallback
- **Calendar Integration:** Google Calendar REST API (OAuth 2.0)

### Testing & Quality
- **Test Framework:** Vitest v4 with isolated test harnesses
- **Type Checking:** TypeScript 5.0 (Strict mode enabled)
- **Linting:** ESLint 9

---

## 🏗️ 5. System Architecture

```mermaid
graph TD
    Client["Client UI (Next.js 15 / React 19 / Tailwind CSS)"] --> API["Next.js Route Handlers (/api/*)"]
    API --> Domain["Domain Services (Booking, Hold, Leave, AI, Outbox)"]
    Domain --> DB[("Supabase PostgreSQL (RLS, Advisory Locks, RPCs)")]
    Domain --> Gemini["Google Gemini API (gemini-3.6-flash)"]
    Domain --> Resend["Resend Email API"]
    Domain --> GCal["Google Calendar REST API"]
```

### Layered Execution Flow
1. **Presentation Layer:** Role-specific workspaces built with React 19 and Radix UI primitives.
2. **API & Validation Layer:** Next.js Route Handlers authenticate sessions, resolve identity (`resolveIdentity`), enforce role guards (`requireRoles`), and validate payloads via Zod schemas.
3. **Domain Service Layer:** TypeScript business logic orchestrates state transitions, schedules, and asynchronous background dispatch.
4. **Database Layer:** Supabase PostgreSQL enforces relational integrity, Row Level Security (RLS), and atomic ACID stored procedures.

---

## ⏱️ 6. Double-Booking Prevention & Temporary Slot Holds

To guarantee zero race-condition double-bookings under high concurrency, HMS implements a two-phase reservation pipeline:

```text
Phase 1: Temporary Hold
-----------------------
Patient selects Slot
       │
       ▼
Call `atomic_hold_slot()` RPC
       │
       ├─ Acquire 64-bit PostgreSQL advisory transaction lock on Slot ID
       ├─ Expire any stale holds on the slot (`expires_at < NOW()`)
       ├─ Lock slot row (`FOR UPDATE`) and verify status is 'AVAILABLE'
       ├─ Verify doctor is not on approved/pending leave
       ├─ Mark slot status as 'HELD'
       └─ Insert record into `slot_holds` with a 5-minute UUID `hold_token`

Phase 2: Booking Confirmation
-----------------------------
Patient clicks Confirm Booking
       │
       ▼
Call `atomic_confirm_booking()` RPC
       │
       ├─ Verify `hold_token` exists, is 'ACTIVE', and `expires_at > NOW()`
       ├─ Check idempotency key to prevent duplicate booking on double-click
       ├─ Transition slot status: 'HELD' → 'BOOKED'
       ├─ Transition hold status: 'ACTIVE' → 'CONSUMED'
       ├─ Insert appointment row with status 'CONFIRMED'
       └─ Enqueue asynchronous outbox notifications
```

---

## 📅 7. Doctor Leave & Automated Conflict Handling

When a doctor submits a leave request:
1. **Overlap Inspection:** The system evaluates all future slots between `start_date` and `end_date`.
2. **Atomic Resolution (`process_doctor_leave_conflicts`):**
   - All `AVAILABLE` slots within the leave window are transitioned to `BLOCKED`.
   - Active holds on those slots are released.
   - Any already `CONFIRMED` appointments are updated to `DOCTOR_LEAVE_CONFLICT` or `RESCHEDULE_REQUIRED`.
3. **Patient Rescheduling Notifications:** Outbox engine dispatches automated rescheduling notifications to affected patients.

---

## 🤖 8. AI Pre-Visit & Post-Visit Clinical Intelligence

Powered by Google Gemini (`gemini-3.6-flash`) via [`lib/ai/gemini.ts`](file:///c:/Users/hp/hospital-management-system/lib/ai/gemini.ts) with strict structured JSON output parsing and Zod runtime schema validation:

- **Pre-Visit Scribe (`PREVISIT_V1`):** Analyzes patient symptoms, duration, and severity into chief complaint, urgency rating (`LOW` | `MEDIUM` | `HIGH`), and 3 targeted diagnostic questions for the doctor.
- **Post-Visit Scribe (`POSTVISIT_V1`):** Translates doctor notes, diagnosis, and prescriptions into plain-language patient summaries, medication administration schedules, and red-flag warnings.
- **Resilience & Fallback:** Patient opt-out consent is respected (`triggerOrSkip`). Missing API keys or network timeouts are logged as non-blocking `FAILED` records in Supabase without interrupting clinical booking.

---

## 📬 9. Notifications, Outbox & Retry Engine

- **Decoupled Outbox:** Outbox events (`outboxBookingConfirmed`, `outboxAppointmentCancelled`, `outboxAppointmentRescheduled`) trigger background dispatch without delaying HTTP API responses.
- **Multi-Provider Architecture:** Resend API HTTP client (production) with fallback to an in-memory database stub (local testing).
- **Deduplication & Retries:** Unique constraint `dedupe_key` prevents duplicate emails. Background worker (`POST /api/notifications/retry`) retries failed sends with exponential backoff up to 3 times.

---

## 📆 10. Google Calendar OAuth & Synchronization

- **OAuth 2.0 Flow:** Doctors authorize their Google account via `/api/calendar/authorize` with `offline` access and `prompt=consent`.
- **Cryptographic Token Vault:** Access and refresh tokens are encrypted at rest using **AES-256-GCM** (`lib/crypto/vault.ts`) before being stored in `user_oauth_tokens`.
- **Event Lifecycle:** Automatically creates (`fireCalendarCreate`), updates (`fireCalendarUpdate`), and deletes (`fireCalendarDelete`) calendar events with attendee invites.

---

## 🔒 11. Security & Authorization Architecture

- **Role-Based Access Control:** Strict permission verification on every route using `resolveIdentity` and `requireRoles`.
- **Service Client Isolation:** Server routines use `createServiceClient()` strictly *after* API boundary authentication and role authorization checks to eliminate recursive RLS cycle evaluation.
- **Payload Sanitization:** All incoming requests are validated against Zod schemas before hitting business logic.
- **Zero Plaintext Secrets:** Sensitive OAuth credentials and tokens are encrypted at rest with authenticated AES-256-GCM.

---

## 🗄️ 12. Database Architecture

PostgreSQL 15+ database organized across 30 tables with 6 domain enums versioned under `supabase/migrations/`:

| Migration File | Description |
| :--- | :--- |
| `20260820170000_base_schema.sql` | Users, Patients, Staff, Departments, Rooms, Admissions, Medicines, Billing |
| `20260820180000_appointment_domain.sql` | Slots, Appointments, Slot Holds, Doctor Availability, Doctor Leave |
| `20260820181000_appointment_rpc.sql` | Atomic PL/pgSQL procedures (`atomic_hold_slot`, `atomic_confirm_booking`, etc.) |
| `20260821060400_ai_visit_intelligence.sql` | Pre-visit and post-visit AI intake schemas |
| `20260821070000_post_visit_reminders.sql` | Medication schedules and reminder tracking |
| `20260821080000_notifications_calendar.sql` | Notification records, OAuth tokens, Google Calendar mappings |
| `20260821090000_notifications_dedupe_meds.sql` | Notification deduplication indices and medication lookahead |
| `20260824000000_security_foundation.sql` | Row Level Security (RLS) policies and security triggers |

---

## 📁 13. Project Directory Structure

```text
hospital-management-system/
├── app/
│   ├── admin/                 # Administrator workspace
│   ├── doctor/                # Doctor workspace
│   ├── nurse/                 # Nurse workspace
│   ├── patient/               # Patient workspace
│   ├── pharmacy/              # Pharmacist workspace
│   ├── api/                   # 62 Next.js REST API Route Handlers
│   ├── layout.tsx             # Root layout & theme providers
│   └── page.tsx               # Public landing page
│
├── components/
│   ├── admin/                 # Admin management & analytics components
│   ├── appointments/          # Slot booking, hold countdown & calendars
│   ├── doctor/                # Doctor availability, notes & prescriptions
│   ├── patient/               # Patient dashboards & intake forms
│   ├── shell/                 # Role-aware responsive app shell
│   ├── ui/                    # Reusable shadcn/ui & Radix primitives
│   └── theme-provider.tsx     # Light/Dark mode provider
│
├── docs/                      # Technical Documentation
│   ├── API.md                 # Full REST API Reference
│   ├── DATABASE.md            # Database Architecture & Stored Procedures
│   ├── GOOGLE_CALENDAR_SETUP.md # Google Calendar OAuth Setup Guide
│   ├── LLM_PROMPTS.md         # AI Prompts & Output Schemas
│   └── SYSTEM_DESIGN.md       # Concise System Design Reference
│
├── lib/
│   ├── ai/                    # Gemini client, pre/post-visit services
│   ├── appointments/          # Booking, hold, availability & outbox engine
│   ├── calendar/              # Google Calendar OAuth & sync service
│   ├── crypto/                # AES-256-GCM cryptographic vault
│   ├── medications/           # Prescription schedules & reminder services
│   ├── notifications/         # Resend & Stub email notification service
│   └── validation/            # Zod request validation schemas
│
├── scripts/
│   ├── clean-demo-dataset.ts  # Script to reset demo dataset
│   └── seed-demo-dataset.ts   # Script to provision demo accounts & data
│
├── supabase/
│   └── migrations/            # Version-controlled PostgreSQL SQL migrations
│
├── tests/                     # Vitest automated test suites
├── utils/
│   └── supabase/              # Browser, server, and service client factories
│
├── .env.example               # Safe environment variables template
├── package.json
└── README.md
```

---

## 🚀 14. Local Setup Instructions

### Prerequisites
- Node.js 18.x or 20.x
- npm or pnpm
- A Supabase project (Free tier or local instance)
- Google Gemini API Key (optional, for AI features)
- Resend API Key (optional, for live email delivery)

### 1. Clone the Repository
```bash
git clone https://github.com/Ziggyyyyyyyy/hospital-management-system.git
cd hospital-management-system
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment Variables
Copy `.env.example` to `.env.local` and populate your credentials:
```bash
cp .env.example .env.local
```

### 4. Apply Database Migrations
Apply all SQL migrations in `supabase/migrations/` sequentially through the Supabase SQL Editor or Supabase CLI:
```bash
npx supabase db push
```

### 5. Seed Demo Data
Populate standard test accounts, departments, doctors, rooms, and pharmacy inventory:
```bash
npm run seed:demo
```

### 6. Run the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🔑 15. Environment Variables Reference

| Variable Name | Required | Scope | Description |
| :--- | :---: | :---: | :--- |
| `NEXT_PUBLIC_SUPABASE_URL` | **Yes** | Client/Server | URL of your Supabase instance |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | **Yes** | Client/Server | Public anonymous key for Supabase Auth |
| `SUPABASE_SERVICE_ROLE_KEY` | **Yes** | Server-only | Secret service role key for admin operations |
| `GEMINI_API_KEY` | Optional | Server-only | Google Gemini API key for AI symptom features |
| `EMAIL_PROVIDER` | Optional | Server-only | `resend`, `sendgrid`, or `stub` (default: `stub`) |
| `RESEND_API_KEY` | Optional | Server-only | Resend API key (`re_...`) for email delivery |
| `EMAIL_FROM` | Optional | Server-only | Sender email address (e.g. `onboarding@resend.dev`) |
| `GOOGLE_CLIENT_ID` | Optional | Server-only | Google OAuth 2.0 Client ID for Calendar sync |
| `GOOGLE_CLIENT_SECRET` | Optional | Server-only | Google OAuth 2.0 Client Secret |
| `GOOGLE_REDIRECT_URI` | Optional | Server-only | OAuth redirect callback URL (`http://localhost:3000/api/calendar/callback`) |
| `ENCRYPTION_MASTER_KEY` | Optional | Server-only | 32-byte key for AES-256 OAuth token encryption |
| `ENCRYPTION_SALT` | Optional | Server-only | Salt for AES-256 OAuth token encryption vault |
| `APPOINTMENT_HOLD_DURATION_SECONDS` | Optional | Server-only | Slot hold expiry duration (default: `300`) |

---

## 👥 16. Demo Accounts

When seeded with `npm run seed:demo`, the following pre-configured demo accounts are available:

| Role | Email | Password | Primary Workspace |
| :--- | :--- | :--- | :--- |
| **Administrator** | `demo-admin@hms.local` | `DemoAdmin123!` | `/admin` |
| **Doctor** | `demo-doctor@hms.local` | `DemoDoctor123!` | `/doctor` |
| **Nurse** | `demo-nurse@hms.local` | `DemoNurse123!` | `/nurse` |
| **Pharmacist** | `demo-pharmacist@hms.local` | `DemoPharm123!` | `/pharmacy` |
| **Patient** | `demo-patient@hms.local` | `DemoPatient123!` | `/patient` |

---

## 🧪 17. Testing & Quality Assurance

The codebase includes an extensive Vitest automated test suite covering all critical business domains:

```bash
# Run all automated test suites
npm test

# Run tests in watch mode
npx vitest

# Run TypeScript strict type check
npx tsc --noEmit

# Run ESLint validation
npm run lint
```

### Verified Test Suites
- `tests/appointment-flow.test.ts`: Slot generation, atomic holding, concurrent hold contention, idempotency, and cancellation.
- `tests/ai-features.test.ts`: Pre-visit intake processing, Zod schema validation, and API failure fallbacks.
- `tests/notifications-calendar.test.ts`: Email delivery, deduplication keys, and AES-256 token encryption.
- `tests/doctor-leave.test.ts`: Overlapping leave detection and appointment conflict resolution.
- `tests/analytics.test.ts`: Departmental revenue, demographics, and visit trend computations.
- `tests/staff.test.ts`: Staff provisioning, role assignment, and validation.
- `tests/auth.test.ts`: RBAC permission guards and session verification.

---

## 📦 18. Build & Deployment Instructions

### Production Build
To create an optimized production build:
```bash
npm run build
```

### Starting Production Server
```bash
npm run start
```

### Vercel Deployment
1. Import the repository into [Vercel](https://vercel.com).
2. Configure your environment variables (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `GEMINI_API_KEY`, `RESEND_API_KEY`, etc.).
3. Deploy!

---

## ⚠️ Medical Disclaimer
This software is built for educational and operational management purposes. It is **not** a certified medical diagnostic device. AI-generated insights are intended solely to assist clinical workflows and must not supersede the professional judgment of qualified healthcare providers.

---

## 📄 License
This project is licensed under the MIT License.
